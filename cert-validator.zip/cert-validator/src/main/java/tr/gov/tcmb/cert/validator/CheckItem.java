package tr.gov.tcmb.cert.validator;

import java.util.Date;

public class CheckItem {

	private String name;
	private String url;
	private Date expiryDate;
	private int thresholdDays;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public boolean isExpired() {

		return !(expiryDate == null || expiryDate.after(new Date()));
	}

	
	public boolean isThresholdPassed() {
		return getThresholdDays() > getDaysToExpire();
	}
	
	public int getDaysToExpire() {

		if (expiryDate == null)
			return 0;

		long diff = expiryDate.getTime() - System.currentTimeMillis();

		int diffDays = (int) (diff / (24 * 60 * 60 * 1000));
		return diffDays;
	}

	public int getThresholdDays() {
		if(thresholdDays == 0) {
			return 7;
		}
		return thresholdDays;
	}

	public void setThresholdDays(int thresholdDays) {
		this.thresholdDays = thresholdDays;
	}

}
