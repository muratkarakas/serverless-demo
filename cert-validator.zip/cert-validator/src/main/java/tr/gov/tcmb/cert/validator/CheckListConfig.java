package tr.gov.tcmb.cert.validator;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "cert")
public class CheckListConfig {

	private List<CheckItem> checklist;

	public List<CheckItem> getChecklist() {
		return checklist;
	}

	public void setChecklist(List<CheckItem> checklist) {
		this.checklist = checklist;
	}

}