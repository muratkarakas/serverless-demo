package tr.gov.tcmb.cert.validator;

import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Date;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CertCheckerService {
	@Autowired
	public CheckListConfig config;
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	public List<CheckItem> validateCurrentStatus() throws Exception {

		List<CheckItem> checklist = config.getChecklist();

		for (CheckItem checkItem : checklist) {
			try {
				Date expiryDate = readExpiryDate(checkItem.getUrl());
				checkItem.setExpiryDate(expiryDate);
			} catch (Exception e) {
				logger.error("Read Error",e);
			}
			
		}
		return checklist;

	}


	public Date readExpiryDate(String urlToCheck) throws Exception {

		Date notAfter = null;

		SSLContext ctx = SSLContext.getInstance("TLS");
		ctx.init(new KeyManager[0], new TrustManager[] { new DefaultTrustManager() }, new SecureRandom());
		SSLContext.setDefault(ctx);

		URL url = new URL(urlToCheck);
		HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
		conn.connect();
		conn.setHostnameVerifier((String hostname, SSLSession session) -> true);
		logger.info(urlToCheck);

		Certificate[] certs = conn.getServerCertificates();
		if (certs != null && certs.length > 0)
			notAfter = ((X509Certificate) certs[0]).getNotAfter();

		conn.disconnect();

		return notAfter;

	}

	public static class DefaultTrustManager implements X509TrustManager {

		@Override
		public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
		}

		@Override
		public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
		}

		@Override
		public X509Certificate[] getAcceptedIssuers() {
			return null;
		}
	}

}